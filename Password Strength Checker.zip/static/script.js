document.getElementById("passwordInput").addEventListener("input", function () {
    const password = this.value;
    fetch("/check", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({ password: password }),
    })
    .then((response) => response.json())
    .then((data) => {
        updateStrengthIndicator(data.strength, data.percentage);
        updateFeedbackList(data.feedback);
    });
});

function updateStrengthIndicator(strength, percentage) {
    const strengthBar = document.getElementById("strengthBar");
    const percentageDisplay = document.getElementById("percentageDisplay");
    let color = "red";

    switch (strength) {
        case "Very Strong":
            color = "green";
            break;
        case "Strong":
            color = "limegreen";
            break;
        case "Moderate":
            color = "orange";
            break;
        case "Weak":
            color = "red";
            break;
        default:
            color = "red";
    }

    strengthBar.style.width = `${percentage}%`;
    strengthBar.style.backgroundColor = color;
    percentageDisplay.textContent = `${Math.round(percentage)}%`;
    percentageDisplay.style.color = color;
}

function updateFeedbackList(feedback) {
    const feedbackList = document.getElementById("feedbackList");
    feedbackList.innerHTML = feedback.map((item) => `<li>${item}</li>`).join("");
}